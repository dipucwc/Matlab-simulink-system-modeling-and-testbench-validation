
%%
function [rxGrid, timingHat, cfoHat] = sl_synchronizer(rxWave)
%% Simulink Cyclic-Prefix Synchronization Wrapper:
%%
%{
The sl_synchronizer function recovers the frame timing and the fractional carrier frequency offset from the impaired
received waveform using the cyclic-prefix maximum-likelihood principle, corrects both, and demodulates the corrected
waveform back to the receiver resource grid. For every candidate timing offset the function accumulates, over all
fourteen OFDM symbols and all receive antennas, the correlation between each cyclic prefix and its repeated segment
one FFT length later, normalizes by the energy of the two windows, and selects the offset that maximizes the metric.
The phase of the winning correlation divided by two pi is the maximum-likelihood estimate of the fractional carrier
frequency offset in subcarrier spacings, because the offset advances the carrier phase by exactly that angle across
one FFT length. The corrected waveform is de-rotated with the estimated offset, advanced to the estimated start, and
demodulated with the unitary CP-OFDM demodulator of the verified chain; the active subcarriers are then extracted
from the centered FFT grid. The estimator is verified by the executed synchronization gates: exact recovery of the
injected 7-sample offset, a residual frequency error below one part in a thousand of the subcarrier spacing in the
noiseless gate, and an unchanged corrected bit error rate at 20 dB.

Auxiliary functions:

    config                        Locked simulation configuration.
    ofdm_demodulate               Unitary CP-OFDM demodulator of the verified chain.

Input:

    rxWave                       Impaired received antenna waveform with padding, samples x nRx.

Output:

    rxGrid                       Synchronized receiver grid of size nSymbols x nSC x nRx.
    timingHat                    Estimated integer timing offset in samples.
    cfoHat                       Estimated carrier frequency offset in subcarrier spacings.
%}


%% Cyclic-prefix timing metric over the candidate offsets:
%%

cfg = config();
cpLen = round(cfg.nFFT/14);
symLen = cfg.nFFT + cpLen;
maxDelay = 32;                                                      % Search range covering the injected offsets.
bestMetric = -1;
timingHat = 0;
bestCorr = complex(0);
for d = 0:maxDelay
    corrSum = complex(0);
    energySum = 0;
    for sym = 1:cfg.nSymbols
        a = d + (sym-1)*symLen + 1;
        head = rxWave(a:a+cpLen-1, :);
        tail = rxWave(a+cfg.nFFT:a+cfg.nFFT+cpLen-1, :);
        corrSum = corrSum + sum(conj(head(:)) .* tail(:));          % CP repeats one FFT length later.
        energySum = energySum + 0.5*(sum(abs(head(:)).^2) + sum(abs(tail(:)).^2));
    end
    metric = abs(corrSum) / max(energySum, eps);
    if metric > bestMetric
        bestMetric = metric;
        timingHat = d;
        bestCorr = corrSum;
    end
end
cfoHat = angle(bestCorr) / (2*pi);                                  % ML fractional CFO from the CP phase advance.


%% Correction and CP-OFDM demodulation of the aligned frame:
%%

nSamples = cfg.nSymbols * symLen;
n = (timingHat:timingHat+nSamples-1).';
segment = rxWave(timingHat+1:timingHat+nSamples, :) .* ...
    exp(-1i*2*pi*cfoHat*n/cfg.nFFT);                                % De-rotate with the estimated offset.
fftGrid = ofdm_demodulate(segment, cfg, size(segment,2));
startBin = (cfg.nFFT - cfg.nSC)/2 + 1;
rxGrid = permute(fftGrid(startBin:startBin+cfg.nSC-1, :, :), [2 1 3]);
end
