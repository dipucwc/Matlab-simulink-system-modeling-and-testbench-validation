%%
%% Adaptive-Stopping Massive MIMO Campaign Driver:
%%
%{
The run_adaptive_massive_campaign script re-executes the end-to-end 64x8 massive MIMO campaign under adaptive Monte
Carlo stopping and writes a journal-grade result file in which every SNR row carries the raw error counts, the exact
Clopper-Pearson 95% confidence bounds, the stopping reason, the runtime, and the seed. The chain, the profile, and
the verification gates are those of the existing project: the script selects the massive profile, runs the gates, and
then calls the adaptive engine with the recommended stopping rule. Rows produced by this script supersede the
fixed-frame matlab_results_massive.csv for every statistical claim, while the fixed-frame file remains valid as the
regression reference of the cross-verification protocol.

Recommended stopping rule (per SNR point): at least 500 frames, then stop at 100 block errors or 500 bit errors,
with an unconditional cap of 20000 frames. At the high-SNR points the cap will be the binding constraint; the
stored stoppingReason column states this explicitly, and the stored bounds state exactly how much the enlarged
sample constrains the true error rate.
%}
%% Configuration, gates, and stopping rule:
%%

clear; clc;
set_sim_profile('massive');                        % Locked 64x8, L = 4 profile of the project.
cfg = config();                                    % Configuration of the locked profile.
seed = 7;                                          % Campaign seed, stored in every result row.
rng(seed);                                         % Seeded random stream.
run_verification_gates(cfg);                       % No unverified result can be produced.

stop.minFrames = 500;                              % Minimum statistical population per point.
stop.maxFrames = 20000;                            % Unconditional frame budget per point.
stop.targetBitErrors = 500;                        % Bit-error target of the stopping rule.
stop.targetBlockErrors = 100;                      % Block-error target of the stopping rule.

snrGrid = -10:5:20;                                % Project SNR grid of the massive campaign.
idealCsi = false;                                  % LS estimation, the executed end-to-end mode.


%% Adaptive campaign execution:
%%

out = run_link_curve_adaptive(cfg, snrGrid, stop, idealCsi);


%% Result file with counts, bounds, stopping reasons, and runtimes:
%%

csvName = 'matlab_results_massive_adaptive.csv';
fid = fopen(csvName, 'w');
fprintf(fid, ['snrDb,ber,berLower95,berUpper95,bler,blerLower95,blerUpper95,', ...
              'numFrames,evaluatedBits,bitErrors,blockErrors,stoppingReason,', ...
              'runtimeSeconds,seed,nTx,nRx,nLayers\n']);
for s = 1:numel(out.snrDb)
    fprintf(fid, '%g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%d,%d,%d,%s,%.3f,%d,%d,%d,%d\n', ...
        out.snrDb(s), out.ber(s), out.berLower95(s), out.berUpper95(s), ...
        out.bler(s), out.blerLower95(s), out.blerUpper95(s), ...
        out.numFrames(s), out.evaluatedBits(s), out.bitErrors(s), out.blockErrors(s), ...
        out.stoppingReason(s), out.runtimeSeconds(s), seed, cfg.nTx, cfg.nRx, cfg.nLayers);
end
fclose(fid);
write_config_log(cfg, 'matlab_results_massive_adaptive_config.txt');   % Locked-configuration provenance log.
fprintf('Adaptive campaign written to %s\n', csvName);


%% BER curve with shaded 95% confidence band:
%%

figure('Color', 'w'); hold on; grid on;
mask = out.bitErrors > 0;                          % Points with observed errors are plotted as estimates.
snrE = out.snrDb(mask);
fill([snrE; flipud(snrE)], ...
     [max(out.berLower95(mask), 1e-12); flipud(out.berUpper95(mask))], ...
     [0.75 0.85 1.0], 'EdgeColor', 'none', 'FaceAlpha', 0.6);          % Shaded exact 95% band.
semilogyMaskedLine(snrE, out.ber(mask));           % Point estimates over the band.
maskZ = ~mask;                                     % Zero-error points are plotted as upper bounds.
if any(maskZ)
    plot(out.snrDb(maskZ), out.berUpper95(maskZ), 'v', ...
        'MarkerFaceColor', [0.2 0.3 0.6], 'MarkerEdgeColor', 'none');
end
set(gca, 'YScale', 'log');
xlabel('Total transmit SNR (dB)'); ylabel('BER');
title(sprintf('Adaptive campaign, 64x8, L = 4: estimates with exact 95%% bounds (seed %d)', seed));
legend({'95% confidence band', 'BER estimate', 'Zero errors: 95% upper bound'}, 'Location', 'southwest');
saveas(gcf, 'ber_massive_adaptive_ci.png');

function semilogyMaskedLine(x, y)
    plot(x, y, '-o', 'LineWidth', 1.4, 'Color', [0.10 0.20 0.55], ...
        'MarkerFaceColor', [0.10 0.20 0.55], 'MarkerEdgeColor', 'none');
end
