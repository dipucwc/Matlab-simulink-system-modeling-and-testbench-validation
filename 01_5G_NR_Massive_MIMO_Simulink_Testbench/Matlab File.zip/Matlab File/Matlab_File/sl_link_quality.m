
%%
function [sinrDb, throughputMbps] = sl_link_quality(shat, layerGrid, blockError)
%% Simulink Link-Quality Measurement Wrapper:
%%
%{
The sl_link_quality function derives the two link-quality figures of the advanced testbench from quantities the
verified chain already produces. The per-layer post-equalization SINR compares the transmitted data symbols of each
layer with the corresponding equalized symbols: the ratio of the mean transmitted-symbol power to the mean squared
equalization error contains, in one number, the residual noise, the residual inter-layer interference, and any
residual synchronization error on that layer, which is exactly the quantity that determines the demapper operating
point. The throughput follows the CRC acceptance decision of the frame: an accepted frame delivers its full payload
in one slot duration and a rejected frame delivers nothing, so the reported value is the goodput of the uncoded
CRC-protected transport chain rather than a nominal peak rate.

Input:

    shat                          Equalized data symbols of size nData x nLayers.
    layerGrid                     Transmit layer grid of size nSymbols x nSC x nLayers.
    blockError                    CRC block-error decision of the frame, zero or one.

Output:

    sinrDb                        Per-layer post-equalization SINR in decibels, 1 x nLayers.
    throughputMbps                CRC-gated payload throughput of the frame in Mbit/s.
%}


%% Per-layer post-equalization SINR:
%%

cfg = config();
[~, ~, dataPositions] = sl_layout();
nData = size(dataPositions, 1);
sinrDb = zeros(1, cfg.nLayers);
for layer = 1:cfg.nLayers
    ref = complex(zeros(nData, 1));
    for index = 1:nData
        ref(index) = layerGrid(dataPositions(index,1), dataPositions(index,2), layer);
    end
    errPow = mean(abs(shat(:,layer) - ref).^2);
    sinrDb(layer) = 10*log10(mean(abs(ref).^2) / max(errPow, eps)); % Signal power over residual error power.
end


%% CRC-gated payload throughput:
%%

payloadBits = nData*cfg.nLayers*cfg.bitsPerSymbol - cfg.crcLen;     % Payload bits carried by one accepted frame.
throughputMbps = (1 - blockError) * payloadBits / cfg.slotDurationS / 1e6;
end
