
%%
function [rxWave, noiseVar] = sl_channel_impairments(waveform, H, snrDb, cfoNorm, timingOffset)
%% Simulink Channel and Impairment Wrapper:
%%
%{
The sl_channel_impairments function propagates the transmitted CP-OFDM waveform through the flat MIMO channel in the
time domain and injects the two synchronization impairments of the advanced testbench: a carrier frequency offset
expressed as a fraction of the subcarrier spacing, and an integer sample timing offset. Because the massive profile
uses a frequency-flat channel, the time-domain matrix multiplication is exactly equivalent to the per-subcarrier
frequency-domain application of the verified chain; the function refuses frequency-selective models so that the
equivalence is never silently violated. Receiver noise is added over the full padded buffer at the fixed
total-transmit-SNR convention. The unitary OFDM transform leaves the white-noise variance unchanged between the time
and grid domains, so the same noiseVar value that the frequency-domain chain uses remains valid for the MMSE
equalizer after demodulation.

Input:

    waveform                      Transmitted CP-OFDM antenna waveform, samples x nTx.
    H                             Channel realization of size nSC x nRx x nTx (flat models only).
    snrDb                         Total transmit SNR in decibels.
    cfoNorm                       Carrier frequency offset in subcarrier spacings.
    timingOffset                  Sample timing offset inserted before the frame; a fractional part is
                                  applied as an ideal all-band fractional delay.

Output:

    rxWave                        Impaired received antenna waveform with padding, samples x nRx.
    noiseVar                      Complex receiver-noise variance at the fixed convention.
%}


%% Flat-channel guard and time-domain propagation:
%%

cfg = config();
if ~any(strcmpi(cfg.channelModel, {'awgn', 'rayleigh_flat', 'rician'}))
    error('sl_channel_impairments requires a frequency-flat channel model.');
end
H0 = squeeze(H(1,:,:));                                             % Flat models repeat one matrix on every subcarrier.
y = waveform * H0.';                                                % y_r(n) = sum_t H0(r,t) x_t(n).


%% Carrier-frequency-offset rotation and integer timing offset:
%%

n = (0:size(y,1)-1).';
y = y .* exp(1i*2*pi*cfoNorm*n/cfg.nFFT);                           % CFO in fractions of the subcarrier spacing.
fracDelay = timingOffset - floor(timingOffset);
if fracDelay > 0
    fBins = ifftshift(((0:size(y,1)-1).' - floor(size(y,1)/2)) / size(y,1));
    y = ifft(fft(y) .* exp(-1i*2*pi*fBins*fracDelay));              % Ideal all-band fractional delay.
end
if isfield(cfg, 'advPhaseNoiseHz') && cfg.advPhaseNoiseHz > 0
    fs = cfg.nFFT * cfg.subcarrierSpacingHz;
    stepVar = 2*pi*cfg.advPhaseNoiseHz/fs;                          % Wiener increment variance per sample.
    phi = cumsum(sqrt(stepVar) * randn(size(y,1), 1));
    y = y .* exp(1i*phi);                                           % Accumulated oscillator phase walk.
end
y = [complex(zeros(floor(timingOffset), size(y,2))); y; ...
     complex(zeros(64, size(y,2)))];                                % Offset padding plus search headroom at the tail.


%% Receiver noise at the fixed total-transmit-SNR convention:
%%

rho = 10^(snrDb/10);
noiseVar = cfg.nLayers / rho;                                       % Unit-power layers make total transmit energy L.
noise = sqrt(noiseVar/2) * (randn(size(y)) + 1i*randn(size(y)));
rxWave = y + noise;
end
