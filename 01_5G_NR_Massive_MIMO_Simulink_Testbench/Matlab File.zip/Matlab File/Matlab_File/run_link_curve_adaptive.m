%%
function out = run_link_curve_adaptive(cfg, snrDbVec, stop, idealCsi)
%% Adaptive-Stopping Link-Level Performance-Curve Engine:
%%
%{
The run_link_curve_adaptive function executes one complete link-level performance curve over a supplied SNR grid
using adaptive Monte Carlo stopping instead of a fixed frame count. At every SNR point the engine keeps simulating
independent frames until it has collected a statistically sufficient error population, and it records, for every
point, the exact error counts, the stopping reason, the exact Clopper-Pearson 95% confidence bounds on the bit and
block error rates, and the wall-clock runtime. The per-frame processing chain is identical to run_link_curve: one
transport-block frame with CRC attachment, scrambling, QAM mapping, and DM-RS insertion, one independent channel
realization, the configured precoder, the effective channel with additive receiver noise at the fixed
total-transmit-SNR level, ideal-CSI or LS-estimated channel knowledge selected by the idealCsi argument, linear
equalization, and the frame-level metric set. Because the chain functions are called unchanged, every verification
gate that protects run_link_curve protects this engine equally.

Stopping rule of one SNR point. The point stops as soon as both conditions hold: at least stop.minFrames frames have
been processed, and either at least stop.targetBlockErrors block errors or at least stop.targetBitErrors bit errors
have been observed. The point also stops unconditionally when stop.maxFrames frames have been processed. The recorded
stopping reason is 'target_errors_reached' in the first case and 'maximum_frames_reached' in the second, so every
CSV row states which regime produced it.

Input:

    cfg                           Complete simulation configuration structure.
    snrDbVec                      SNR grid of the curve in decibels.
    stop                          Stopping-rule structure with the fields:
                                      stop.minFrames          minimum frames per point (e.g. 500)
                                      stop.maxFrames          maximum frames per point (e.g. 20000)
                                      stop.targetBitErrors    target bit-error population (e.g. 500)
                                      stop.targetBlockErrors  target block-error population (e.g. 100)
    idealCsi                      True for the ideal-CSI reference mode, false for LS estimation.

Output (arrays aligned with the SNR grid):

    out.snrDb                     SNR grid of the curve.
    out.ber, out.bler             Point estimates.
    out.berLower95/berUpper95     Exact Clopper-Pearson 95% bounds on the BER.
    out.blerLower95/blerUpper95   Exact Clopper-Pearson 95% bounds on the BLER.
    out.numFrames                 Frames actually processed at the point.
    out.evaluatedBits             Information bits actually evaluated at the point.
    out.bitErrors, out.blockErrors  Raw error counts of the point.
    out.stoppingReason            'target_errors_reached' or 'maximum_frames_reached' per point.
    out.runtimeSeconds            Wall-clock runtime of the point.
    out.evm, out.nmse, out.capacity  Frame-averaged auxiliary metrics.
    out.shatSample                Equalized symbol block of the final frame.
%}
%% Stopping-rule defaults and output arrays:
%%

if nargin < 3 || isempty(stop), stop = struct(); end
if ~isfield(stop,'minFrames'),         stop.minFrames = 500;           end
if ~isfield(stop,'maxFrames'),         stop.maxFrames = 20000;         end
if ~isfield(stop,'targetBitErrors'),   stop.targetBitErrors = 500;     end
if ~isfield(stop,'targetBlockErrors'), stop.targetBlockErrors = 100;   end
assert(stop.maxFrames >= stop.minFrames, ...
    'run_link_curve_adaptive:badStop', 'maxFrames must be at least minFrames.');

nS = numel(snrDbVec);                              % Number of SNR points of the curve.
out.snrDb = snrDbVec(:);                           % SNR grid returned with the results.
z = zeros(nS,1);
out.ber = z; out.bler = z;                         % Point estimates.
out.berLower95 = z; out.berUpper95 = z;            % Exact 95% bounds on the BER.
out.blerLower95 = z; out.blerUpper95 = z;          % Exact 95% bounds on the BLER.
out.numFrames = z; out.evaluatedBits = z;          % Executed sample sizes.
out.bitErrors = z; out.blockErrors = z;            % Raw error counts.
out.stoppingReason = strings(nS,1);                % Stopping reason per point.
out.runtimeSeconds = z;                            % Wall-clock runtime per point.
out.evm = z; out.nmse = z; out.capacity = z;       % Frame-averaged auxiliary metrics.
out.shatSample = [];                               % Final-frame symbols for constellation figures.


%% Adaptive Monte Carlo loop:
%%

for s = 1:nS                                       % One SNR point per iteration.
    snrDb = snrDbVec(s);                           % SNR of the current point.
    be=0; nb=0; blk=0; ev=0; nm=0; cp=0; f=0;      % Per-point accumulators and frame counter.
    tPoint = tic;                                  % Runtime measurement of the point.

    while true
        f = f + 1;                                 % One independent frame per iteration.
        frame = build_frame(cfg);                  % Transport block, CRC, scrambling, QAM, layers, and DM-RS.
        H = generate_channel(cfg);                 % One independent channel realization.
        W = compute_precoder(cfg, H);              % Precoder of the current realization.
        [rx, nv] = apply_mimo_channel(frame.layerGrid, H, W, snrDb);   % Channel and receiver noise.
        if idealCsi
            G = true_effective_channel(H, W);      % Ideal-CSI reference mode.
        else
            G = estimate_effective_channel_ls(rx, frame, cfg);         % LS estimation on the DM-RS.
        end
        shat = equalize_mimo(rx, G, frame.dataPositions, nv, cfg);     % Layer symbols on the data elements.
        met = compute_frame_metrics(shat, frame, G, H, W, snrDb, cfg); % Frame-level metric set.
        be = be + met.bitErrors; nb = nb + met.nBits;                  % Bit-error accumulation.
        blk = blk + met.blockError;                % Block-error accumulation.
        ev = ev + met.evm; nm = nm + met.nmse;     % EVM and NMSE accumulation.
        cp = cp + met.capacityBpsHz;               % Capacity accumulation.

        targetReached = (blk >= stop.targetBlockErrors) || (be >= stop.targetBitErrors);
        if f >= stop.minFrames && targetReached    % Sufficient statistical evidence collected.
            out.stoppingReason(s) = "target_errors_reached";
            break;
        end
        if f >= stop.maxFrames                     % Frame budget of the point exhausted.
            out.stoppingReason(s) = "maximum_frames_reached";
            break;
        end
    end

    out.runtimeSeconds(s) = toc(tPoint);           % Runtime of the point.
    out.numFrames(s) = f;                          % Frames actually processed.
    out.evaluatedBits(s) = nb;                     % Bits actually evaluated.
    out.bitErrors(s) = be; out.blockErrors(s) = blk;                   % Raw error counts.
    out.ber(s) = be/nb;                            % Bit error rate of the point.
    out.bler(s) = blk/f;                           % Block error rate of the point.
    [out.berLower95(s),  out.berUpper95(s)]  = binomial_ci95(be, nb);  % Exact bounds on the BER.
    [out.blerLower95(s), out.blerUpper95(s)] = binomial_ci95(blk, f);  % Exact bounds on the BLER.
    out.evm(s) = ev/f;                             % Average RMS EVM of the point.
    out.nmse(s) = nm/f;                            % Average estimation NMSE of the point.
    out.capacity(s) = cp/f;                        % Average layer-domain capacity of the point.
    out.shatSample = shat;                         % Final-frame symbols kept for constellation figures.

    fprintf(['SNR %6.1f dB | frames %6d | bits %9d | bitErr %6d | blkErr %5d | ', ...
             'BER %.3e [%.3e, %.3e] | BLER %.4f [%.4f, %.4f] | %s | %.1f s\n'], ...
        snrDb, f, nb, be, blk, out.ber(s), out.berLower95(s), out.berUpper95(s), ...
        out.bler(s), out.blerLower95(s), out.blerUpper95(s), out.stoppingReason(s), ...
        out.runtimeSeconds(s));
end
end
