
%%
%%
% Advanced Hierarchical Massive MIMO Testbench Builder:
%%
%{
The build_advanced_testbench script constructs the advanced Simulink testbench of the project: the verified
frequency-domain processing chain extended with a time-domain CP-OFDM waveform path, injected synchronization
impairments, a cyclic-prefix maximum-likelihood synchronizer, per-layer SINR and CRC-gated throughput measurement,
and a hierarchical organization into five named subsystems. The script first builds and wires the complete flat
chain with the same proven block classes and helpers as the baseline builder, so that every connection is explicit
and auto-routed, then folds the wired stages into the subsystems 01 Transmitter, 02 Channel and Impairments,
03 Synchronization, 04 Receiver, and 05 Metrics and Verification with the Simulink subsystem-creation service,
which generates every subsystem port from the existing connectivity. The impairment operating point is set by two
top-level constants, a carrier frequency offset of 0.15 subcarrier spacings and a timing offset of 7 samples,
matching the executed synchronization gates; fractional timing offsets and Wiener oscillator phase noise are
additionally supported by the impairment wrapper through config.m. A Runtime Checks block compares the synchronizer
estimates with the injected values on every step within tolerances matched to the Monte Carlo operating range,
drives a warning-mode Assertion block, and logs the per-frame decision, so the sweep reports a measured
synchronization hit rate per SNR point instead of hiding estimator degradation or aborting on a single miss; the
key signals are named on the diagram for readable tracing and selective logging. Both the chain verification gates and the synchronization gates run in
the model InitFcn before the first step, a licensed Spectrum Analyzer and Constellation Diagram attach to the
transmit waveform and the equalized symbols when available, and every metric, estimate, and waveform is logged to
the workspace. All numerical work is performed by the verified wrapper functions; the model adds structure,
impairments, synchronization, and measurement, never a second numerical implementation.

Auxiliary functions:

    set_sim_profile               Persistent profile switch read by config everywhere.
    run_verification_gates        Pre-simulation gates of the verified chain.
    run_sync_verification         Deterministic synchronization gates of the advanced bench.
    sl_waveform_tx                Time-domain transmit wrapper.
    sl_channel_impairments        Flat-channel propagation with impairment injection.
    sl_synchronizer               Cyclic-prefix timing and frequency recovery.
    sl_link_quality               Per-layer SINR and CRC-gated throughput.

Output:

    NR_PDSCH_Advanced_Testbench.slx    Hierarchical advanced testbench with impairments and synchronization.
%}


%% Massive profile, model shell, and derived dimensions:
%%

set_sim_profile('massive');
cfg = config();
mdl = 'NR_PDSCH_Advanced_Testbench';
if bdIsLoaded(mdl)
    close_system(mdl, 0);
end
if exist([mdl '.slx'], 'file')
    delete([mdl '.slx']);
end
new_system(mdl);
open_system(mdl);
set_param(mdl, 'SolverType', 'Fixed-step', 'FixedStep', '1', ...
    'StopTime', '59', 'SimulationMode', 'normal');

nSym = cfg.nSymbols; nSC = cfg.nSC; nL = cfg.nLayers;
nTx = cfg.nTx; nRx = cfg.nRx;
cpLen = round(cfg.nFFT/14);
nSamp = nSym*(cfg.nFFT + cpLen);                                    % Waveform samples of one frame.
nPad = nSamp + 64 + 7;                                              % Padded buffer at the default 7-sample offset.
s = rng; frame0 = build_frame(cfg); rng(s);                         % Layout probe; the RNG stream stays intact.
nData = size(frame0.dataPositions, 1);
nBitsCrc = numel(frame0.bitsCrc);
fs = cfg.nFFT * cfg.subcarrierSpacingHz;                                          % Compact-grid sample rate of the waveform.


%% MATLAB Function block scripts (thin, fixed-size, extrinsic):
%%

mfScript = containers.Map();
mfScript('PDSCH Transmitter') = sprintf([ ...
'function [layerGrid, bitsCrc] = fcn(tick) %%#ok<INUSD>\n' ...
'%% build_frame: TB -> CRC24A -> Gold scrambling -> QAM -> layers + DM-RS\n' ...
'coder.extrinsic(''sl_transmitter'');\n' ...
'layerGrid = complex(zeros(%d,%d,%d));\n' ...
'bitsCrc = zeros(%d,1);\n' ...
'[layerGrid, bitsCrc] = sl_transmitter(tick);\n'], nSym, nSC, nL, nBitsCrc);
mfScript('Waveform Modulator') = sprintf([ ...
'function waveform = fcn(layerGrid, W)\n' ...
'%% sl_waveform_tx: precoding and unitary CP-OFDM modulation\n' ...
'coder.extrinsic(''sl_waveform_tx'');\n' ...
'waveform = complex(zeros(%d,%d));\n' ...
'waveform = sl_waveform_tx(layerGrid, W);\n'], nSamp, nTx);
mfScript('MIMO Channel Generator') = sprintf([ ...
'function H = fcn(tick) %%#ok<INUSD>\n' ...
'%% generate_channel: one flat massive realization per frame\n' ...
'coder.extrinsic(''sl_channel'');\n' ...
'H = complex(zeros(%d,%d,%d));\n' ...
'H = sl_channel(tick);\n'], nSC, nRx, nTx);
mfScript('Wideband SVD Precoder') = sprintf([ ...
'function W = fcn(H)\n' ...
'%% compute_precoder: wideband eigenbeamforming\n' ...
'coder.extrinsic(''sl_precoder'');\n' ...
'W = complex(zeros(%d,%d));\n' ...
'W = sl_precoder(H);\n'], nTx, nL);
mfScript('Impairment Injection') = sprintf([ ...
'function [rxWave, noiseVar] = fcn(waveform, H, snrDb, cfoNorm, timingOffset)\n' ...
'%% sl_channel_impairments: flat channel, CFO, timing offset, and noise\n' ...
'coder.extrinsic(''sl_channel_impairments'');\n' ...
'rxWave = complex(zeros(%d,%d));\n' ...
'noiseVar = 0;\n' ...
'[rxWave, noiseVar] = sl_channel_impairments(waveform, H, snrDb, cfoNorm, timingOffset);\n'], nPad, nRx);
mfScript('CP Synchronizer') = sprintf([ ...
'function [rxGrid, timingHat, cfoHat] = fcn(rxWave)\n' ...
'%% sl_synchronizer: CP ML timing and CFO recovery, correction, demodulation\n' ...
'coder.extrinsic(''sl_synchronizer'');\n' ...
'rxGrid = complex(zeros(%d,%d,%d));\n' ...
'timingHat = 0; cfoHat = 0;\n' ...
'[rxGrid, timingHat, cfoHat] = sl_synchronizer(rxWave);\n'], nSym, nSC, nRx);
mfScript('LS Channel Estimator') = sprintf([ ...
'function Ghat = fcn(rxGrid)\n' ...
'%% estimate_effective_channel_ls: LS on DM-RS\n' ...
'coder.extrinsic(''sl_estimator'');\n' ...
'Ghat = complex(zeros(%d,%d,%d));\n' ...
'Ghat = sl_estimator(rxGrid);\n'], nSC, nRx, nL);
mfScript('ZF-MMSE Equalizer') = sprintf([ ...
'function shat = fcn(rxGrid, Ghat, noiseVar)\n' ...
'%% equalize_mimo: ZF or unbiased MMSE, per config.m\n' ...
'coder.extrinsic(''sl_equalizer'');\n' ...
'shat = complex(zeros(%d,%d));\n' ...
'shat = sl_equalizer(rxGrid, Ghat, noiseVar);\n'], nData, nL);
mfScript('Demap Descramble CRC Metrics') = sprintf([ ...
'function [bitErrors, nBits, blockError, evm, nmse, capacity] = fcn(shat, layerGrid, bitsCrc, Ghat, H, W, snrDb)\n' ...
'%% compute_frame_metrics: BER, BLER, EVM, NMSE, and layer capacity\n' ...
'coder.extrinsic(''sl_metrics'');\n' ...
'bitErrors = 0; nBits = 0; blockError = 0; evm = 0; nmse = 0; capacity = 0;\n' ...
'[bitErrors, nBits, blockError, evm, nmse, capacity] = sl_metrics(shat, layerGrid, bitsCrc, Ghat, H, W, snrDb);\n']);
mfScript('Runtime Checks') = sprintf([ ...
'function ok = fcn(timingHat, cfoHat, cfoNorm, timingOffset)\n' ...
'%% Per-frame synchronization check: estimates against the injected values.\n' ...
'%% Tolerances admit the estimator variance of the Monte Carlo operating\n' ...
'%% range; the sweep reports the hit rate per SNR point from this flag.\n' ...
'ok = double((abs(timingHat - floor(timingOffset)) <= 2) && (abs(cfoHat - cfoNorm) < 0.05));\n']);
mfScript('Link Quality') = sprintf([ ...
'function [sinrDb, throughputMbps] = fcn(shat, layerGrid, blockError)\n' ...
'%% sl_link_quality: per-layer SINR and CRC-gated throughput\n' ...
'coder.extrinsic(''sl_link_quality'');\n' ...
'sinrDb = zeros(1,%d);\n' ...
'throughputMbps = 0;\n' ...
'[sinrDb, throughputMbps] = sl_link_quality(shat, layerGrid, blockError);\n'], nL);


%% Blocks (flat layout: TX | CHANNEL+IMPAIRMENTS | SYNC | RX | METRICS):
%%

addMF = @(name, pos) add_block('simulink/User-Defined Functions/MATLAB Function', [mdl '/' name], 'Position', pos);
addMF('PDSCH Transmitter',            [140 150 320 230]);
addMF('Waveform Modulator',           [400 150 560 230]);
addMF('MIMO Channel Generator',       [140 330 320 400]);
addMF('Wideband SVD Precoder',        [400 330 560 400]);
addMF('Impairment Injection',         [660 140 850 280]);
addMF('CP Synchronizer',              [930 140 1090 260]);
addMF('LS Channel Estimator',         [1170 300 1330 360]);
addMF('ZF-MMSE Equalizer',            [1410 150 1570 250]);
addMF('Demap Descramble CRC Metrics', [1670 140 1890 330]);
addMF('Link Quality',                 [1670 380 1890 460]);
addMF('Runtime Checks',               [1170 400 1330 470]);

add_block('simulink/Sources/Digital Clock', [mdl '/Frame Clock'], ...
    'Position', [30 200 90 230], 'SampleTime', '1');
add_block('simulink/Sources/Constant', [mdl '/SNR (dB)'], ...
    'Position', [400 470 480 500], 'Value', '20', 'SampleTime', '1');
add_block('simulink/Sources/Constant', [mdl '/CFO (subcarriers)'], ...
    'Position', [400 520 480 550], 'Value', '0.15', 'SampleTime', '1');
add_block('simulink/Sources/Constant', [mdl '/Timing offset (samples)'], ...
    'Position', [400 570 480 600], 'Value', '7', 'SampleTime', '1');
add_block('simulink/Signal Routing/Goto', [mdl '/Goto SNR'], ...
    'Position', [520 470 600 500], 'GotoTag', 'SNR', 'TagVisibility', 'global');
add_block('simulink/Signal Routing/Goto', [mdl '/Goto CFO'], ...
    'Position', [520 520 600 550], 'GotoTag', 'CFO', 'TagVisibility', 'global');
add_block('simulink/Signal Routing/Goto', [mdl '/Goto Delay'], ...
    'Position', [520 570 600 600], 'GotoTag', 'DEL', 'TagVisibility', 'global');
add_block('simulink/Signal Routing/From', [mdl '/From SNR ch'],  'Position', [560 232 640 258], 'GotoTag', 'SNR');
add_block('simulink/Signal Routing/From', [mdl '/From CFO ch'],  'Position', [560 262 640 288], 'GotoTag', 'CFO');
add_block('simulink/Signal Routing/From', [mdl '/From Delay ch'],'Position', [560 292 640 318], 'GotoTag', 'DEL');
add_block('simulink/Signal Routing/From', [mdl '/From SNR met'], 'Position', [1560 302 1640 328], 'GotoTag', 'SNR');
add_block('simulink/Signal Routing/From', [mdl '/From CFO rt'],  'Position', [1040 400 1120 426], 'GotoTag', 'CFO');
add_block('simulink/Signal Routing/From', [mdl '/From Delay rt'],'Position', [1040 436 1120 462], 'GotoTag', 'DEL');
add_block('simulink/Model Verification/Assertion', [mdl '/Sync Assertion'], ...
    'Position', [1400 410 1450 460], 'Enabled', 'on', 'StopWhenAssertionFail', 'off');
    % Warning mode: a miss is flagged and logged, not fatal; the sweep
    % reports the synchronization hit rate per SNR point.


%% Metric sinks: displays, logging, cumulative BER, and the sync estimates:
%%

addDisp = @(name, pos) add_block('simulink/Sinks/Display', [mdl '/' name], 'Position', pos);
addDisp('BLER frame',      [1980 205 2070 235]);
addDisp('EVM',             [1980 250 2070 280]);
addDisp('NMSE',            [1980 295 2070 325]);
addDisp('Capacity',        [1980 340 2070 370]);
addDisp('SINR per layer',  [1980 390 2100 430]);
addDisp('Throughput Mbps', [1980 440 2100 470]);
addDisp('Timing estimate', [1150 140 1250 170]);
addDisp('CFO estimate',    [1150 185 1250 215]);
addTW = @(name, vname, pos) add_block('simulink/Sinks/To Workspace', [mdl '/' name], ...
    'Position', pos, 'VariableName', vname, 'SaveFormat', 'Array');
addTW('Log bitErrors',   'log_bitErrors',   [2160 120 2280 150]);
addTW('Log nBits',       'log_nBits',       [2160 165 2280 195]);
addTW('Log blockError',  'log_blockError',  [2160 210 2280 240]);
addTW('Log EVM',         'log_evm',         [2160 255 2280 285]);
addTW('Log NMSE',        'log_nmse',        [2160 300 2280 330]);
addTW('Log capacity',    'log_capacity',    [2160 345 2280 375]);
addTW('Log SINR',        'log_sinr',        [2160 390 2280 420]);
addTW('Log throughput',  'log_throughput',  [2160 435 2280 465]);
addTW('Log timingHat',   'log_timingHat',   [1150 230 1270 260]);
addTW('Log cfoHat',      'log_cfoHat',      [1150 275 1270 305]);
addTW('Log syncOk',      'log_syncOk',      [1150 320 1270 350]);

add_block('simulink/Discrete/Discrete-Time Integrator', [mdl '/Sum bit errors'], ...
    'Position', [1980 60 2030 90], 'SampleTime', '1');
add_block('simulink/Discrete/Discrete-Time Integrator', [mdl '/Sum bits'], ...
    'Position', [1980 110 2030 140], 'SampleTime', '1', 'InitialCondition', '1');
    % InitialCondition 1 keeps the BER divider defined at the first step;
    % against roughly 6e5 accumulated bits the bias is below 1e-5 relative.
add_block('simulink/Math Operations/Divide', [mdl '/BER ratio'], 'Position', [2070 75 2110 115]);
addDisp('Cumulative BER', [2160 75 2280 105]);


%% MATLAB Function block scripts (via the Stateflow API):
%%

rt = sfroot;
names = keys(mfScript);
for i = 1:numel(names)
    ch = rt.find('-isa', 'Stateflow.EMChart', 'Path', [mdl '/' names{i}]);
    ch.Script = mfScript(names{i});
end


%% Block descriptions shown in the model browser:
%%

descr = { ...
 'PDSCH Transmitter',            'One PDSCH frame per step through the verified build_frame chain.'; ...
 'Waveform Modulator',           'Precoding and unitary CP-OFDM modulation of the antenna waveform.'; ...
 'MIMO Channel Generator',       'One flat massive channel realization per frame.'; ...
 'Wideband SVD Precoder',        'Wideband eigenbeamforming precoder of the verified chain.'; ...
 'Impairment Injection',         'Flat-channel propagation with CFO, timing offset, optional phase noise, and receiver noise.'; ...
 'CP Synchronizer',              'Cyclic-prefix ML timing and CFO recovery, correction, and demodulation.'; ...
 'LS Channel Estimator',         'DM-RS least-squares effective-channel estimation.'; ...
 'ZF-MMSE Equalizer',            'Zero-forcing or unbiased MMSE detection per config.m.'; ...
 'Demap Descramble CRC Metrics', 'Demapping, descrambling, CRC decision, and the frame metric set.'; ...
 'Link Quality',                 'Per-layer post-equalization SINR and CRC-gated throughput.'; ...
 'Runtime Checks',               'Automated pass/fail of the synchronizer against the injected impairments.'};
for i = 1:size(descr, 1)
    set_param([mdl '/' descr{i,1}], 'Description', descr{i,2});
end


%% Wiring (autorouted):
%%

L = @(a,b) add_line(mdl, a, b, 'autorouting', 'on');
N = @(a,b,nm) set_param(add_line(mdl, a, b, 'autorouting', 'on'), 'Name', nm);
L('Frame Clock/1', 'PDSCH Transmitter/1');
L('Frame Clock/1', 'MIMO Channel Generator/1');
L('SNR (dB)/1', 'Goto SNR/1');
L('CFO (subcarriers)/1', 'Goto CFO/1');
L('Timing offset (samples)/1', 'Goto Delay/1');
N('PDSCH Transmitter/1', 'Waveform Modulator/1', 'layerGrid');
L('Wideband SVD Precoder/1', 'Waveform Modulator/2');               % W
L('MIMO Channel Generator/1', 'Wideband SVD Precoder/1');           % H -> precoder
N('Waveform Modulator/1', 'Impairment Injection/1', 'txWaveform');
L('MIMO Channel Generator/1', 'Impairment Injection/2');            % H
L('From SNR ch/1', 'Impairment Injection/3');                       % SNR
L('From CFO ch/1', 'Impairment Injection/4');                       % CFO
L('From Delay ch/1', 'Impairment Injection/5');                     % timing offset
N('Impairment Injection/1', 'CP Synchronizer/1', 'rxWaveform');
N('CP Synchronizer/1', 'LS Channel Estimator/1', 'rxGrid');
L('CP Synchronizer/1', 'ZF-MMSE Equalizer/1');                      % rxGrid
L('CP Synchronizer/2', 'Runtime Checks/1');
L('CP Synchronizer/3', 'Runtime Checks/2');
L('From CFO rt/1', 'Runtime Checks/3');
L('From Delay rt/1', 'Runtime Checks/4');
L('Runtime Checks/1', 'Sync Assertion/1');
L('Runtime Checks/1', 'Log syncOk/1');
L('CP Synchronizer/2', 'Timing estimate/1');
L('CP Synchronizer/2', 'Log timingHat/1');
L('CP Synchronizer/3', 'CFO estimate/1');
L('CP Synchronizer/3', 'Log cfoHat/1');
N('LS Channel Estimator/1', 'ZF-MMSE Equalizer/2', 'Ghat');
L('Impairment Injection/2', 'ZF-MMSE Equalizer/3');                 % noiseVar
N('ZF-MMSE Equalizer/1', 'Demap Descramble CRC Metrics/1', 'shat');
L('PDSCH Transmitter/1', 'Demap Descramble CRC Metrics/2');         % layerGrid (reference)
L('PDSCH Transmitter/2', 'Demap Descramble CRC Metrics/3');         % bitsCrc (reference)
L('LS Channel Estimator/1', 'Demap Descramble CRC Metrics/4');      % Ghat
L('MIMO Channel Generator/1', 'Demap Descramble CRC Metrics/5');    % H
L('Wideband SVD Precoder/1', 'Demap Descramble CRC Metrics/6');     % W
L('From SNR met/1', 'Demap Descramble CRC Metrics/7');              % SNR
L('ZF-MMSE Equalizer/1', 'Link Quality/1');                         % shat
L('PDSCH Transmitter/1', 'Link Quality/2');                         % layerGrid
L('Demap Descramble CRC Metrics/3', 'Link Quality/3');              % blockError
L('Demap Descramble CRC Metrics/1', 'Sum bit errors/1');
L('Demap Descramble CRC Metrics/1', 'Log bitErrors/1');
L('Demap Descramble CRC Metrics/2', 'Sum bits/1');
L('Demap Descramble CRC Metrics/2', 'Log nBits/1');
L('Sum bit errors/1', 'BER ratio/1');
L('Sum bits/1', 'BER ratio/2');
L('BER ratio/1', 'Cumulative BER/1');
L('Demap Descramble CRC Metrics/3', 'BLER frame/1');
L('Demap Descramble CRC Metrics/3', 'Log blockError/1');
L('Demap Descramble CRC Metrics/4', 'EVM/1');
L('Demap Descramble CRC Metrics/4', 'Log EVM/1');
L('Demap Descramble CRC Metrics/5', 'NMSE/1');
L('Demap Descramble CRC Metrics/5', 'Log NMSE/1');
L('Demap Descramble CRC Metrics/6', 'Capacity/1');
L('Demap Descramble CRC Metrics/6', 'Log capacity/1');
L('Link Quality/1', 'SINR per layer/1');
L('Link Quality/1', 'Log SINR/1');
L('Link Quality/2', 'Throughput Mbps/1');
L('Link Quality/2', 'Log throughput/1');


%% Passive RF monitoring on the waveform and the equalized symbols:
%%

addTW('Log txWaveform', 'log_txWaveform', [660 470 790 500]);
L('Waveform Modulator/1', 'Log txWaveform/1');
addTW('Log shat', 'log_shat', [1410 470 1530 500]);
L('ZF-MMSE Equalizer/1', 'Log shat/1');
spectrumAttached = false;
for cand = {'dspsnks4/Spectrum Analyzer', 'dsp/Spectrum Analyzer', ...
            'spectrumAnalyzerBlockLib/Spectrum Analyzer'}
    try
        add_block(cand{1}, [mdl '/Tx Spectrum'], 'Position', [660 540 720 600]);
        spectrumAttached = true;
        break
    catch
    end
end
if spectrumAttached
    L('Waveform Modulator/1', 'Tx Spectrum/1');
    try set_param([mdl '/Tx Spectrum'], 'SampleRate', num2str(fs)); catch, end
end
try
    add_block('dspsnks4/Constellation Diagram', [mdl '/Rx Constellation'], ...
        'Position', [1410 540 1470 600]);
    L('ZF-MMSE Equalizer/1', 'Rx Constellation/1');
catch
end


%% Hierarchical grouping into the five named subsystems:
%%

groups = { ...
    '01 Transmitter',               {'PDSCH Transmitter', 'Waveform Modulator'}; ...
    '02 Channel and Impairments',   {'MIMO Channel Generator', 'Wideband SVD Precoder', ...
                                     'Impairment Injection', 'From SNR ch', 'From CFO ch', 'From Delay ch'}; ...
    '03 Synchronization',           {'CP Synchronizer'}; ...
    '04 Receiver',                  {'LS Channel Estimator', 'ZF-MMSE Equalizer'}; ...
    '05 Metrics and Verification',  {'Demap Descramble CRC Metrics', 'Link Quality', 'From SNR met', ...
                                     'Runtime Checks', 'From CFO rt', 'From Delay rt', 'Sync Assertion', ...
                                     'Sum bit errors', 'Sum bits', 'BER ratio'}};
for g = 1:size(groups, 1)
    handles = zeros(1, numel(groups{g,2}));
    for b = 1:numel(groups{g,2})
        handles(b) = get_param([mdl '/' groups{g,2}{b}], 'Handle');
    end
    Simulink.BlockDiagram.createSubsystem(handles);                 % Ports generated from the wired connectivity.
    created = find_system(mdl, 'SearchDepth', 1, 'BlockType', 'SubSystem', 'Name', 'Subsystem');
    set_param(created{1}, 'Name', groups{g,1});
end


%% Gates in the InitFcn, annotation, and save:
%%

set_param(mdl, 'InitFcn', sprintf([ ...
    'cfg = config();\n' ...
    'run_verification_gates(cfg);   %% chain gates before results\n' ...
    'run_sync_verification();       %% synchronization gates before results']));
note = Simulink.Annotation([mdl '/Advanced hierarchical testbench: verified numerical chain with CP-OFDM waveform path,']);
note.Position = [140 660];
note2 = Simulink.Annotation([mdl '/injected CFO and timing impairments, cyclic-prefix ML synchronization, per-layer SINR, and CRC-gated throughput.']);
note2.Position = [140 680];
save_system(mdl);
fprintf('Advanced hierarchical testbench ready: %s.slx\n', mdl);
