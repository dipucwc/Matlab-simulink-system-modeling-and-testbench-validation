%%
function [pLower, pUpper] = binomial_ci95(k, n)
%% Exact Clopper-Pearson 95% Confidence Interval for a Binomial Proportion:
%%
%{
The binomial_ci95 function returns the exact two-sided Clopper-Pearson 95% confidence interval for a binomial
proportion estimated from k observed events in n trials. The bounds are the Beta-distribution quantiles

    pLower = B( alpha/2;   k,   n - k + 1 )
    pUpper = B( 1 - alpha/2; k + 1, n - k )

with alpha = 0.05, evaluated with the base-MATLAB inverse incomplete beta function, so no toolbox is required. The
boundary cases are handled exactly: zero observed events give a lower bound of zero, and k = n gives an upper bound
of one. For k = 0 the returned upper bound is the exact zero-error bound whose rule-of-three approximation is 3/n.

Input:

    k                             Number of observed events (bit errors or block errors).
    n                             Number of trials (evaluated bits or frames).

Output:

    pLower                        Lower 95% confidence bound on the true proportion.
    pUpper                        Upper 95% confidence bound on the true proportion.
%}
%% Exact Beta-quantile bounds:
%%

alpha = 0.05;                                      % Two-sided 95% confidence level.
k = double(k); n = double(n);                      % Exact arithmetic on the counts.
assert(n > 0 && k >= 0 && k <= n, 'binomial_ci95:badCounts', 'Counts must satisfy 0 <= k <= n, n > 0.');

if k == 0
    pLower = 0;                                    % No lower evidence with zero events.
else
    pLower = betaincinv(alpha/2, k, n - k + 1);    % Exact lower Clopper-Pearson bound.
end

if k == n
    pUpper = 1;                                    % No upper evidence with all-event trials.
else
    pUpper = betaincinv(1 - alpha/2, k + 1, n - k);% Exact upper Clopper-Pearson bound.
end
end
