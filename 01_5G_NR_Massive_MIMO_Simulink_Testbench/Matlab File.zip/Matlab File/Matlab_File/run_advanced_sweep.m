
%%
function results = run_advanced_sweep(snrGrid)
%% Advanced Testbench SNR Sweep Runner:
%%
%{
The run_advanced_sweep function turns the advanced Simulink testbench into a campaign instrument. For every SNR
point of the supplied grid the function sets the top-level SNR constant of NR_PDSCH_Advanced_Testbench, runs the
model for its full sixty-frame stop time, and collects the cumulative bit statistics, the block-error rate, the
mean EVM, NMSE, capacity, per-layer SINR, and CRC-gated throughput, together with the mean timing and frequency
estimates and the per-frame synchronization hit rate of the warning-mode runtime check, from the workspace logs of
the run. The chain gates and the synchronization gates
execute automatically in the model InitFcn before the first step of every point, and the warning-mode runtime check flags
every frame in which the synchronizer leaves its tolerance window, which the hit-rate column of the result table
quantifies per SNR point. One CSV row per SNR point is written next
to the other result tables so that the Simulink sweep can be compared directly against the scripted MATLAB and
Python reference curves under the identical impairment operating point.

Input:

    snrGrid                       SNR grid in decibels; the massive-profile grid of config is used when absent.

Output:

    results                       Table with one row per SNR point, also written to
                                  simulink_advanced_sweep.csv in the results folder.
%}


%% Grid, model, and result preallocation:
%%

set_sim_profile('massive');
cfg = config();
if nargin < 1 || isempty(snrGrid)
    snrGrid = cfg.snrDb;
end
mdl = 'NR_PDSCH_Advanced_Testbench';
if ~bdIsLoaded(mdl)
    if ~exist([mdl '.slx'], 'file')
        error('Build the advanced testbench first with build_advanced_testbench.');
    end
    load_system(mdl);
end
nPoints = numel(snrGrid);
[ber, bler, evm, nmse, capacity, throughput, timingMean, cfoMean, syncHitRate] = deal(zeros(nPoints, 1));
sinr = zeros(nPoints, cfg.nLayers);


%% One full model run per SNR point:
%%

snrBlock = [mdl '/05 Metrics and Verification/SNR (dB)'];
if ~any(strcmp(find_system(mdl, 'BlockType', 'Constant'), snrBlock))
    snrBlock = [mdl '/SNR (dB)'];                                   % Constant stays top-level in this layout.
end
for p = 1:nPoints
    set_param(snrBlock, 'Value', num2str(snrGrid(p)));
    out = sim(mdl, 'ReturnWorkspaceOutputs', 'on');                 % Gates run in the InitFcn of every point.
    ber(p) = sum(out.log_bitErrors) / sum(out.log_nBits);
    bler(p) = mean(out.log_blockError);
    evm(p) = mean(out.log_evm);
    nmse(p) = mean(out.log_nmse);
    capacity(p) = mean(out.log_capacity);
    throughput(p) = mean(out.log_throughput);
    sinr(p, :) = mean(out.log_sinr, 1);
    timingMean(p) = mean(out.log_timingHat);
    cfoMean(p) = mean(out.log_cfoHat);
    syncHitRate(p) = mean(out.log_syncOk);
    fprintf('SNR=%5.1f dB  BER=%.3e  BLER=%.3f  throughput=%.2f Mbit/s  timing=%.2f  cfo=%+.4f  syncHit=%.2f\n', ...
        snrGrid(p), ber(p), bler(p), throughput(p), timingMean(p), cfoMean(p), syncHitRate(p));
end


%% Result table and CSV record:
%%

results = table(snrGrid(:), ber, bler, evm, nmse, capacity, throughput, ...
    timingMean, cfoMean, syncHitRate, sinr, 'VariableNames', ...
    {'snrDb', 'ber', 'bler', 'evm', 'nmse', 'capacityBpsHz', ...
     'throughputMbps', 'timingHatMean', 'cfoHatMean', 'syncHitRate', 'sinrDbPerLayer'});
outDir = fileparts(cfg.outputCsv);
if ~isempty(outDir) && ~exist(outDir, 'dir')
    mkdir(outDir);
end
writetable(results, fullfile(outDir, 'simulink_advanced_sweep.csv'));
fprintf('Advanced Simulink sweep written to simulink_advanced_sweep.csv\n');
end
