
%%
function waveform = sl_waveform_tx(layerGrid, W)
%% Simulink Time-Domain Transmit Wrapper:
%%
%{
The sl_waveform_tx function converts the layer-domain resource grid of one frame into the transmitted CP-OFDM
antenna waveform for the advanced Simulink testbench. The wideband precoder maps the layer symbols to the antenna
domain on every resource element, the antenna symbols are placed on the active subcarriers centered in the FFT
window, and the unitary CP-OFDM modulator of the verified chain produces the time-domain waveform. Because the
modulator is the same ofdm_modulate function that verification gate three confirms at machine precision, the
time-domain path introduces no new numerical treatment of the transmit signal.

Auxiliary functions:

    config                        Locked simulation configuration.
    ofdm_modulate                 Unitary CP-OFDM modulator of the verified chain.

Input:

    layerGrid                     Transmit layer grid of size nSymbols x nSC x nLayers.
    W                             Wideband precoder of size nTx x nLayers.

Output:

    waveform                      Time-domain CP-OFDM antenna waveform, samples x nTx.
%}


%% Antenna-domain precoding of every resource element:
%%

cfg = config();
[nSym, nSc, nL] = size(layerGrid);
nTx = size(W, 1);
antennaGrid = complex(zeros(nSym, nSc, nTx));
for m = 1:nSym
    x = W * squeeze(layerGrid(m,:,:)).';                            % Antenna symbols of all subcarriers of symbol m.
    antennaGrid(m,:,:) = x.';
end


%% Centered FFT-grid placement and CP-OFDM modulation:
%%

fftGrid = complex(zeros(cfg.nFFT, nSym, nTx));
startBin = (cfg.nFFT - nSc)/2 + 1;                                  % Active band centered in the FFT window.
fftGrid(startBin:startBin+nSc-1, :, :) = permute(antennaGrid, [2 1 3]);
waveform = ofdm_modulate(fftGrid, cfg);
end
