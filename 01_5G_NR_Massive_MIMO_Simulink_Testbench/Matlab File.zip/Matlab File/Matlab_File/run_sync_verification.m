
%%
function results = run_sync_verification()
%% Synchronization Verification Gates:
%%
%{
The run_sync_verification function executes the deterministic synchronization gates of the advanced testbench in
plain MATLAB before any Simulink run, mirroring the executed Python gates on the same algorithm definitions. Gate S1
passes the clean time-domain path with no impairment through the complete chain and requires an exact zero timing
estimate, a negligible frequency estimate, and zero bit errors, which proves that the CP-OFDM waveform detour is
numerically equivalent to the verified frequency-domain chain. Gate S2 injects a 7-sample timing offset and a
0.15-subcarrier carrier frequency offset without noise and requires exact timing recovery, a residual frequency
error below one part in a thousand of the subcarrier spacing, and zero bit errors after correction. Both gates use
the massive flat-Rayleigh profile with fixed seeds, and the function raises an error on any failure so that a broken
synchronizer can never produce results silently.

Auxiliary functions:

    sl_waveform_tx                Time-domain transmit wrapper of the advanced testbench.
    sl_channel_impairments        Flat-channel propagation with impairment injection.
    sl_synchronizer               Cyclic-prefix timing and frequency recovery.

Output:

    results                       Structure with the gate decisions and the measured estimates.
%}


%% Deterministic massive-profile configuration and gate S1:
%%

set_sim_profile('massive');                                         % Persistent profile: every internal config() call
cfg = config();                                                     % inside the wrappers must see the flat profile.
results = struct();
rng(1000, 'twister');
frame = build_frame(cfg);
H = generate_channel(cfg);
W = compute_precoder(cfg, H);
wave = sl_waveform_tx(frame.layerGrid, W);
[rxWave, noiseVar] = sl_channel_impairments(wave, H, 200, 0, 0);    % Effectively noiseless operating point.
[rxGrid, dHat, cfoHat] = sl_synchronizer(rxWave);
Ghat = estimate_effective_channel_ls(rxGrid, frame, cfg);
shat = equalize_mimo(rxGrid, Ghat, frame.dataPositions, noiseVar, cfg);
met = compute_frame_metrics(shat, frame, Ghat, H, W, 200, cfg);
results.s1 = (dHat == 0) && (abs(cfoHat) < 1e-3) && (met.bitErrors == 0);
fprintf('  %s  S1 clean time-domain path: d_hat=%d, cfo_hat=%+.2e, errors=%d/%d\n', ...
    statusWord(results.s1), dHat, cfoHat, met.bitErrors, met.nBits);


%% Gate S2 with the injected impairments:
%%

rng(1001, 'twister');
frame = build_frame(cfg);
H = generate_channel(cfg);
W = compute_precoder(cfg, H);
wave = sl_waveform_tx(frame.layerGrid, W);
[rxWave, noiseVar] = sl_channel_impairments(wave, H, 200, 0.15, 7);
[rxGrid, dHat, cfoHat] = sl_synchronizer(rxWave);
Ghat = estimate_effective_channel_ls(rxGrid, frame, cfg);
shat = equalize_mimo(rxGrid, Ghat, frame.dataPositions, noiseVar, cfg);
met = compute_frame_metrics(shat, frame, Ghat, H, W, 200, cfg);
results.s2 = (dHat == 7) && (abs(cfoHat - 0.15) < 1e-3) && (met.bitErrors == 0);
fprintf('  %s  S2 noiseless CFO and delay: d_hat=%d, cfo_hat=%+.5f, errors=%d/%d\n', ...
    statusWord(results.s2), dHat, cfoHat, met.bitErrors, met.nBits);

%% Gate S5 with a fractional timing offset:
%%

rng(1002, 'twister');
frame = build_frame(cfg);
H = generate_channel(cfg);
W = compute_precoder(cfg, H);
wave = sl_waveform_tx(frame.layerGrid, W);
[rxWave, noiseVar] = sl_channel_impairments(wave, H, 200, 0.10, 7.4);
[rxGrid, dHat, cfoHat] = sl_synchronizer(rxWave);
Ghat = estimate_effective_channel_ls(rxGrid, frame, cfg);
shat = equalize_mimo(rxGrid, Ghat, frame.dataPositions, noiseVar, cfg);
met = compute_frame_metrics(shat, frame, Ghat, H, W, 200, cfg);
results.s5 = (dHat == 7) && (met.bitErrors == 0);
fprintf('  %s  S5 fractional delay 7.4: d_hat=%d, cfo_hat=%+.5f, errors=%d/%d\n', ...
    statusWord(results.s5), dHat, cfoHat, met.bitErrors, met.nBits);

if ~(results.s1 && results.s2 && results.s5)
    error('Synchronization verification failed; the advanced testbench must not run.');
end
fprintf('Synchronization gates passed.\n');
end


%% Gate status word:
%%

function word = statusWord(flag)
if flag
    word = 'PASS';
else
    word = 'FAIL';
end
end
